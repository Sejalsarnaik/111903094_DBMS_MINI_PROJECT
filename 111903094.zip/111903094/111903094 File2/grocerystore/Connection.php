<?php 

$conn = mysqli_connect("localhost", "root", "", "grocery store");
if(mysqli_connect_error()){
    echo "can not connect";
}


?>